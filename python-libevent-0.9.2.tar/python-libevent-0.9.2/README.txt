python-libevent - Python bindings for libevent
========================================================================

See the "samples" directory and the tests for now.
